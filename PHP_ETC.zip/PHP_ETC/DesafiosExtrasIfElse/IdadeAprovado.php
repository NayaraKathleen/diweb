<?php 
    $idade = 18;
    $aprovado = "Sim";
    if (($idade >= 21) and ($aprovado == "Sim")) {
        echo "Você foi aprovado no exame"
    }
    else {
        echo "Você foi reprovado no exame"
    }
?>