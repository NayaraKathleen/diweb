<?php 
    $num = 2;

    if ($num < 0) {
        echo "o número $num é negativo";
    }
    elseif ($num == 0) {
        echo "Esse é o número $num";
    }
    else {
        echo "o Número $num é positivo";
    }
?>