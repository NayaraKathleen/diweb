<?php  
    $num = 2;

    if ($num % 2 == 0) {
        echo "Par"
    }
    else {
        echo "Impar"
    }
?>